package com.ninfo.app;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder>{
    private Context context;
    private List<UserMode> userModeList;

    public UserAdapter(Context context, List<UserMode> userModeList) {
        this.context = context;
        userModeList = new ArrayList<>();
    }
    public void add(UserMode userMode) {
        userModeList.add(userMode);
        notifyDataSetChanged();

    }
    public void clear(){
        if (userModeList != null) {
            userModeList.clear();
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_row,parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        UserMode userMode =userModeList.get(position);
        holder.name.setText(userMode.getUserName());
        holder.email.setText(userMode.getUserEmail());

      holder.itemView.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent intent = new Intent(context, ChatActivity.class);
              intent.putExtra("id",userMode.getUserId());
              context.startActivity(intent);
          }
      });


    }

    @Override
    public int getItemCount() {
        if (userModeList == null) {
            return 0;
        }
        return userModeList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView name,email;
        public MyViewHolder (@NonNull View itemview) {
            super(itemview);
            name = itemview.findViewById(R.id.userName);
            email = itemview.findViewById(R.id.userEmail);

        }

    }
}
